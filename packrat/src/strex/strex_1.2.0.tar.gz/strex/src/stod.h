#ifndef STOD_H_
#define STOD_H_

#include <Rcpp.h>
using namespace Rcpp;


NumericVector char_to_num(CharacterVector x, bool commas);


#endif  // STOD_H_
