#ifndef STREX_MYMATH_H
#define STREX_MYMATH_H

inline int64_t my_abs(int64_t x) {
  return (x < 0) ? -x : x;
}

#endif  // STREX_MYMATH_H
