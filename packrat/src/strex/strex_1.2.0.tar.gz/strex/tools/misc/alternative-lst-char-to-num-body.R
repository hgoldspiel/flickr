  lapply(x, char_to_num, commas = commas)
