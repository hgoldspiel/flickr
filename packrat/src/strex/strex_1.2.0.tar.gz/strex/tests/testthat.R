library(testthat)
library(strex)

test_check("strex")
