#ifndef _ESCAPE_H_
#define _ESCAPE_H_

SEXP ore_escape (SEXP text_);

#endif
