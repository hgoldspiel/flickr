#ifndef _ZZZ_H_
#define _ZZZ_H_

SEXP ore_init ();

SEXP ore_done ();

#endif
