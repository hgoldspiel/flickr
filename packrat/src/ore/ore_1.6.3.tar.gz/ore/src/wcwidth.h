#ifndef _WCWIDTH_H_
#define _WCWIDTH_H_

int mk_wcwidth (wchar_t ucs);

#endif
