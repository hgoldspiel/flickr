#ifndef _SPLIT_H_
#define _SPLIT_H_

SEXP ore_split (SEXP regex_, SEXP text_, SEXP start_, SEXP simplify_);

#endif
