library(testthat)
test_check("ore")
