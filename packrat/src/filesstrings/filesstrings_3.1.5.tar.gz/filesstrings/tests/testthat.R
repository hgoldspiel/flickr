library(testthat)
library(filesstrings)

test_check("filesstrings")
