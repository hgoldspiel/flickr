library(testthat)
library(ijtiff)

print(Sys.info())

test_check("ijtiff")
