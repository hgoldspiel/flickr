#' @aliases scico-package
"_PACKAGE"
