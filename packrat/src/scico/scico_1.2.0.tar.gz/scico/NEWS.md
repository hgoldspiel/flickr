# scico 1.2.0

* Added cyclic colour palettes

# scico 1.1.0

* Added discrete versions of the scales

# scico 1.0.0

* First release
