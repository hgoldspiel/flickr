library(testthat)
library(scico)

test_check("scico")
