# Forest Pix API

The Forest Pix API is implemented in python with flask and deployed on google app engine.

Is this thing on? `http https://herp-atlas-f960c.appspot.com/_ah/health` should return 200, ok.


#### Authentication
In production, auth requests with a json web token returned from firebase. Include the token in the Authorization header.
```
Authorization: JWT <jwt token>
```

### Development

```
pyvenv .venv # one time, in root of directory

. .venv/bin/activate.fish
pip install -r requirements.txt

python main.py
```

### Deployment

Deploy: `make dep`

The `Dockerfile` sets up the environment. The `app.yaml` file simply says "see the dockerfile".
