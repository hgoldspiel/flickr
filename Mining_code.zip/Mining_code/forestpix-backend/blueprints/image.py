import re
import requests
import sys
import json
import time
from collections import defaultdict
from flask import Blueprint, request, jsonify, abort
from dateutil.parser import parse as parse_datetime

from google.cloud import vision

from common import datastore
from common.google_retry import retry
from common.ids import generate_id

from scripts.rects import rects
from scripts.pics import pics

ds = datastore.ds
from_list = datastore.from_list


kind = 'image'
plural_kind = 'images'

DAY_SECONDS = 60*60*24

client = vision.Client.from_service_account_json('./keyfile.json')

def create():
  crud = Blueprint(kind + '.crud', 'api.%s' % kind)

  @crud.route('')
  def list_images():

    image_tags = []

    all_images = []

    """for bbox in rects:
     # print('in loop')
    #bbox = rects[0]
      flickr_response = search(bbox)
      curr_images = extract_pics_from_response(flickr_response)
      all_images = all_images + curr_images

    #image_tags = []
    #for image in all_images:
      #time.sleep(.1)

     # image_tag = create_image_tag(image)
     # image_tags.append(image_tag)
    #for image in image_urls:
     # image_tag = {}
     # image_tag['url'] = image
     # image_tag['tags'] = get_tags_for_image(image)
      #image_tag['tags'] = create_image_tag(image)
     # image_tags.append(image_tag)"""
    curr_images = extract_pics_from_response(pics)
    all_images = all_images + curr_images
    image = all_images[0]
    image = create_image_tag(image);
    image_tags.append(image);

    return jsonify(image_tags)

  return crud

def search(bbox):
  print('In search');
  url_base = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=4c9d2ce08311918c4bf6b3eada7d7d45&extras=owner_name,date_taken,date_upload,geo,tags&min_date_upload=2015-11-27T00:29:06.839600-05:00&format=json&nojsoncallback=1&"
  url = url_base + "bbox=" + str(bbox[0]) + "," + str(bbox[1]) + "," + str(bbox[2]) + "," + str(bbox[3])

  response = requests.request("GET", url).json()

  # add urls to the json
  # can't always rely on 'url_o' in API request, but we can make the url on our own
  for photo in response['photos']['photo']:
    photo.update({'url': get_url(photo)});

  return response


def get_url(photo):
  url = "https://farm{}.staticflickr.com/{}/{}_{}.jpg".format(
    photo['farm'],
    photo['server'],
    photo['id'],
    photo['secret']
  );
  return url

def filter_images(images):
  confirmed_ids = requests.request("GET", "https://forest-pix.firebaseio.com/confirmedImageIds.json").json()
  if confirmed_ids:
    print('here')
    confirmed_ids = list(confirmed_ids.values())
    images = [image for image in images if image['id'] not in confirmed_ids]
  else:
    confirmed_ids = []
    images = [image for image in images if image['id'] not in confirmed_ids]
  return images

def extract_pics_from_response(r):
  print('in extract_pics_from_response');
  # currently just looking in the past year
  curr_time = int(time.time())
  cutoff_date = curr_time - (DAY_SECONDS * 365)
  unconfirmed = filter_images(r)
  images = []
  if unconfirmed:
    photo = unconfirmed[0]

    # filter those within the cutoff date
    #if(int(photo['dateupload']) >= cutoff_date):


    #if (photo['id'] in confirmed_ids):
     # print('is confirmed')


    image = {
      'url' : photo['url'],
      'id' : photo['id'],
      'dateupload' : parse_datetime(photo['dateupload']),
      'latitude' : photo['latitude'],
      'longitude' : photo['longitude'],
      'datetaken' : photo['datetaken']
    }
    #print (image)
    images.append(image)

  return images


def get_tags_for_image(img_uri):
  print ('in get_tags_for_image')
    # Instantiates a client
  assert(img_uri)
  # Load image into memory
  image = client.image(source_uri=img_uri)
  labels = image.detect_labels()

  label_descriptions = []
  for label in labels:
    label_descriptions.append(label.description)

  return label_descriptions

def get_labels(img_uri):
  print('in get_labels');
  # Instantiates a client
  # credentials = GoogleCredentials.get_application_default(

  # Load image into memory
  #client = vision.Client()

  response = requests.request("GET", img_uri, timeout=60)
  image = client.image(content=response.content)

  # Performs label detection on the image files
  labels = image.detect_labels()
  #print(image)
  return labels


# takes in an image object and return tags and image_data
def create_image_tag(image):
  print('in create_image_tag');
  labels = get_labels(image['url'])
  tag_list = []
  for label in labels:
    tag_list.append(label.description)
  #print(tag_list)
  return {
    'tags' : tag_list,
    'image_data' : image
  }
