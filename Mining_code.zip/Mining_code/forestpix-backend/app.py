import logging

from flask import Flask, request
from flask_cors import CORS

from api import config, firebase_jwt_auth, standard_routes
from blueprints import image as image_blueprint
from common.json_encoder import CustomJSONEncoder

ALLOW_UNAUTHORIZED = [
  standard_routes.APP_ENGINE_HEALTHCHECK_REGEX,
  r'^/images$',
]

def create_app(configuration):
  app = Flask(__name__)
  CORS(app)

  app.config.from_object(configuration)
  app.json_encoder = CustomJSONEncoder
  logging.basicConfig(level=logging.INFO)

  firebase_jwt_auth.require_auth_for_all_routes(app, allow_unauthorized=ALLOW_UNAUTHORIZED)
  standard_routes.setup(app)

  app.register_blueprint(image_blueprint.create(), url_prefix='/images')

  return app

# set `app` as module variable so gunicorn can find it
app = create_app(config)

if __name__ == '__main__':
  # This is used when running locally. Gunicorn is used to run the
  # application on Google App Engine, see Dockerfile.
  app = create_app(config)

  app.run(host='127.0.0.1', port=8080, debug=True)
