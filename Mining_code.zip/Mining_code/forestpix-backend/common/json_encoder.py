from datetime import datetime

from flask.json import JSONEncoder

class CustomJSONEncoder(JSONEncoder):
   def default(self, obj):
     if isinstance(obj, datetime):
       return obj.isoformat()
     else:
       return JSONEncoder.default(self, obj)
