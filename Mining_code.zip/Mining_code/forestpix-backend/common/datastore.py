from datetime import datetime, timedelta
from cachetools.func import ttl_cache
from flask import current_app
from google.cloud import datastore

from api import config

builtin_list = list
ds = datastore.Client(config.PROJECT_ID)

@ttl_cache(maxsize=1, ttl=1200)
def get_client():
  return datastore.Client(current_app.config['PROJECT_ID'])

def from_list(entities):
  return [from_entity(entity) for entity in entities]

def from_entity(entity):
  """Translates Datastore results into the format expected by the
  application.

  Datastore typically returns:
    [Entity{key: (kind, id), prop: val, ...}]

  This returns:
    {id: id, prop: val, ...}
  """
  if not entity:
    return None
  if isinstance(entity, builtin_list):
    entity = entity.pop()

  entity['id'] = entity.key.id_or_name
  result = {}
  for k, v in entity.items():
    if isinstance(v, datastore.Key):
      v = v.id_or_name
    result[k] = v

  return result

def multi_list(kinds, filter_bys={}, limit=10, cursor=None, order=['createdAt']):
  multiple_entities = {}
  for kind in kinds:
    multiple_entities[kind] = list(kind, filter_bys, limit, cursor, order)[0]

  return multiple_entities

def list(kind, filter_bys={}, limit=10, cursor=None, order=['createdAt']):
  ds = get_client()
  query = ds.query(kind=kind, order=order)

  for filter_by_key, filter_by_val in filter_bys.items():
    if filter_by_key is '30Days':
      query.add_filter('date', '>=', (datetime.now() - timedelta(days=30)).isoformat())
    else:
      query.add_filter(filter_by_key, '=', filter_by_val)

  it = query.fetch(limit=limit, start_cursor=cursor)
  page = next(it.pages)

  entities = builtin_list(map(from_entity, page))
  next_cursor = (
        it.next_page_token.decode('utf-8')
        if it.next_page_token else None)

  return entities, next_cursor

def read(kind, id):
  ds = get_client()
  key = ds.key(kind, id)
  result = ds.get(key)
  return from_entity(result)

def update(kind, id, data, exclude_from_indexes=()):
  ds = get_client()

  if isinstance(id, datastore.Key):
    key = id
  elif id:
    key = ds.key(kind, id)
  else:
    key = ds.key(kind)

  entity = datastore.Entity(
    key=key,
    exclude_from_indexes=exclude_from_indexes)

  entity.update(data)
  ds.put(entity)
  return from_entity(entity)

def create(kind, data, exclude_from_indexes=()):
  return update(kind, None, data, exclude_from_indexes=exclude_from_indexes)

def delete(kind, id):
  ds = get_client()
  key = ds.key(kind, id)
  ds.delete(key)
