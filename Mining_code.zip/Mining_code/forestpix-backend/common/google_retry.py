from itertools import chain
import time
import grpc

def retry(fn, retries=2):
  for retry_delay in delays(retries):

    if retry_delay > 0:
      time.sleep(retry_delay)

    try:
      return fn()

    except Exception as e:
      status_code = get_google_status_code(e)

      # retry on 500 level errors
      if status_code == grpc.StatusCode.UNAVAILABLE:
        continue
      else:
        raise

  raise RuntimeError("Retries ({}) exceeded for {}".format(retries, fn))

def delays(retries):
  sleep_times = ((2**i) for i in range(-2, retries-2)) # (0.25, 0.5, 1, 2, 4, 8, ...)
  return chain([0], sleep_times) # prepend 0, we want the first request to fire immediately.

def get_google_status_code(e):
  """
  Google makes it way too hard to determine if an exception represents "Unavailable".
  Returns the status code or None.
  """
  if hasattr(e, 'code') and callable(e.code):
    return e.code()
  if hasattr(e, 'cause'):
    return get_google_status_code(e.cause)
  return None
