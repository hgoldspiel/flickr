from datetime import timezone, timedelta
import time

from dateutil.tz import tzutc

def day_of_year(date):
  return date.utctimetuple().tm_yday

UTC_ISO_FORMAT_WITHOUT_SUBSECONDS = '%Y-%m-%dT%H:%M:%SZ'
def format_date_as_key(date):
  assert date.tzinfo.utcoffset(None) == timedelta(0), "Received date without a UTC timezone."
  return date.strftime(UTC_ISO_FORMAT_WITHOUT_SUBSECONDS)
