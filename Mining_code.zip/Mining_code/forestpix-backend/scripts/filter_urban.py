# collect_flickr_pics.py

# takes in rectangles, and returns images geotagged in that area from the
# flickr search endpoint

# Usage: python collect_flickr_pics.py < rects

import sys
import json
import requests
import time
import datetime
from google.cloud import vision
from rects import rects
from shapely.geometry import shape as make_shape
from shapely.geometry import MultiPolygon, Point
from pics2 import pics
#from urban_areas_northern_forest import urbanjson

from oauth2client.client import GoogleCredentials
client = vision.Client.from_service_account_json('./keyfile.json')

DAY_SECONDS = 60*60*24

with open('/Users/Danielkatz/Upstream/forestpix-backend/scripts/urban_areas_northern_forest.geojson') as geojson_file:
  urbanjson = json.load(geojson_file)

# *********************************
# flickr search

# passed in coordinates which define the search area
def search(bbox):
  print('In search');
  url_base = "https://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=4c9d2ce08311918c4bf6b3eada7d7d45&extras=owner_name,date_taken,date_upload,geo,tags&min_date_upload=2015-11-27T00:29:06.839600-05:00&format=json&nojsoncallback=1&"
  url = url_base + "bbox=" + str(bbox[0]) + "," + str(bbox[1]) + "," + str(bbox[2]) + "," + str(bbox[3])

  response = requests.request("GET", url).json()

  # add urls to the json
  # can't always rely on 'url_o' in API request, but we can make the url on our own
  for photo in response['photos']['photo']:
    photo.update({'url': get_url(photo)});

  return response

# https://farm{farm-id}.staticflickr.com/{server-id}/{id}_{secret}.jpg
def get_url(photo):
  url = "https://farm{}.staticflickr.com/{}/{}_{}.jpg".format(
    photo['farm'],
    photo['server'],
    photo['id'],
    photo['secret']
  );
  return url

def extract_pics_from_response(r):
  print('in extract_pics_from_response');
  # currently just looking in the past year
  curr_time = int(time.time())
  #cutoff_date = curr_time - (DAY_SECONDS * 365)
  cutoff_date = curr_time - (DAY_SECONDS * 364)

  images = []
  for photo in r['photos']['photo']:

    # filter those within the cutoff date
    if(int(photo['dateupload']) < cutoff_date):
      break


    image = {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [float(photo['longitude']), float(photo['latitude'])]
      },
      "properties": {
        'url' : photo['url'],
        'dateupload' : datetime.datetime.fromtimestamp(int(photo['dateupload'])).strftime('%Y-%m-%d %H:%M:%S'),
        'latitude' : photo['latitude'],
        'longitude' : photo['longitude'],
        'datetaken' : photo['datetaken'],
        'id' : photo['id'],
        'caption' : photo['caption'] if 'caption' in photo else '',
      }
    }

    images.append(image)

  return images

def make_shapes(urban_json):
    shapes = []
    for shape in urban_json['features']:
      shapes.append(make_shape(shape['geometry']))
    #print (shapes)
    return shapes

def filter_urban_areas(images):
  shapes = make_shapes(urbanjson)
  filtered_images = []
  for image in images:
    coord = Point(image['geometry']['coordinates'][0], image['geometry']['coordinates'][1])
    #print (coord)
    #for shape in shapes:
     # if shape.contains(coord):
        #print ('intersection')
    if (any((shape.contains(coord) for shape in shapes))) == 0:
      filtered_images.append(image)
  return filtered_images



# *********************************

#rects = json.loads(sys.stdin.read())
#print('down here');
#all_images = []

#bbox = rects[0];
#flickr_response = search(bbox)
#curr_images = extract_pics_from_response(flickr_response)
#all_images = all_images + curr_images
all_images = filter_urban_areas(pics)

#image_tags = []
print("number of images: " + str(len(all_images)))
f = open('pics4.py','w')
f.write(str(all_images))
#print(all_images)
#for image in all_images:
  #time.sleep(.1)
  #image_tag = create_image_tag(image)
  #image_tags.append(image_tag)

#print(image_tags)
