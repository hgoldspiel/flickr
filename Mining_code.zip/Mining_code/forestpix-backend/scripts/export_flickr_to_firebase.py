from firebase import firebase
from pics5 import pics
firebase = firebase.FirebaseApplication('https://forest-pix.firebaseio.com/', None)
firebase.put('/filtered', 'type', 'FeatureCollection')
firebase.put('/filtered','features', pics)
