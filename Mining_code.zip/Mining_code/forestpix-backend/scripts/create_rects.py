# create_rects.py
# given a geojson file, create rectangles which encompass that area

# usage: python create_rects.py < ../data/NFCounties_dissolved.geojson > rects

import sys
import json
from shapely.geometry import Polygon
from shapely.geometry import box


# RECTANGLE CREATION 

def create_rects(feature):
  coord_tuples = []

  for coordinate_pair in feature['geometry']['coordinates'][0][0]:
    coord_tuples.append((coordinate_pair[0], coordinate_pair[1]))


  poly = Polygon(coord_tuples)

  poly_box = box(poly.bounds[0], poly.bounds[1], poly.bounds[2], poly.bounds[3])
  rects = []
  quad_rect(poly, poly_box, rects)

  # geojsonify_rects(rects)
  return rects

def poly_to_rects (poly) :
    poly_box = box(poly.bounds[0], poly.bounds[1], poly.bounds[2], poly.bounds[3])

def quad_rect(poly, rect, rects):
  i_r = intersection_ratio(poly, rect)
  if(i_r > .98):
    rects.append(rect)
    # return quad_rect
  elif(i_r > .1 and rect.area < (poly.area / 1000)):
    rects.append(rect)
  elif(i_r < .001):
    return
  else:
    if( rect.area < (poly.area / 1000) ):
      rects.append(rect)
      return
    quads = createQuadrants(rect.bounds)
    for quad in quads:
      quad_rect(poly, quad, rects)


def createQuadrants (bb):
  # center point on the bounding box
  center = ( (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2 )

  quads = []
  quads.append(box(bb[0], bb[1], center[0], center[1]))
  quads.append(box(center[0], bb[1], bb[2], center[1]))
  quads.append(box(bb[0], center[1], center[0], bb[3]))
  quads.append(box(center[0], center[1], bb[2], bb[3]))

  return quads

# how much of the rectangle is in the polygon?
def intersection_ratio (poly, rect):
  insersect_area = poly.intersection(rect).area
  rect_area = rect.area
  return insersect_area / rect_area


# from a rectangle, extract the bottom left and top right coordinates in bbox format
def extract_bbox(rect):
  coord_list = list(rect.exterior.coords)
  lats = []
  longs = []
  for coord in coord_list:
    longs.append(coord[0])
    lats.append(coord[1])
  return [min(longs), min(lats), max(longs), max(lats)]


# EXECUTION

json_input = json.loads(sys.stdin.read())


bboxes = []
for feature in json_input["features"]:
  rects = create_rects(feature)

  for rect in rects:
    bbox = extract_bbox(rect)
    bboxes.append(bbox)

print(json.dumps(bboxes))

