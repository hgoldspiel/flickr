# Modified from Google, edited to work with our setup.
#
# Copyright 2016 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import logging
import os
import ssl
import re
from urllib.parse import urlencode, quote_plus

from cachetools.func import ttl_cache
from Crypto.Util import asn1
import jwt
from jwt.contrib.algorithms.pycrypto import RSAAlgorithm
import jwt.exceptions
from flask import request, abort
import requests

from api import config
from common import datastore

ds = datastore.ds

ONE_HOUR = 3600 # seconds

# For App Engine, pyjwt needs to use PyCrypto instead of Cryptography.
jwt.register_algorithm('RS256', RSAAlgorithm(RSAAlgorithm.SHA256))

# This URL contains a list of active certificates used to sign Firebase auth tokens.
FIREBASE_CERTIFICATES_URL = 'https://www.googleapis.com/robot/v1/metadata/x509/' \
    'securetoken@system.gserviceaccount.com'

ADMIN_UIDS = [
  'TuBg9OZb5TTfNis3DvN0tC4JHAD3', # marshall@upstream.tech
]

def require_auth_for_all_routes(app, allow_unauthorized=[]):
  allow_unauthorized = set(allow_unauthorized)
  allow_unauthorized_patterns = [re.compile(pattern) for pattern in allow_unauthorized]

  @app.before_request
  def validate_firebase_jwt():
    if request.method == 'OPTIONS':
      return

    if request.method == 'GET' and any([re.search(p, request.path) for p in allow_unauthorized_patterns]):
      return

    try:
      claims = firebase_jwt_claims()

      if request.method == 'DELETE' and not claims['user_id'] in ADMIN_UIDS:
        raise 'DELETE action requires admin user'

      assert claims
    except Exception as e:
      print(e)
      abort(401, 'Invalid, expired or missing JWT Authorization header.')

@ttl_cache(maxsize=4, ttl=ONE_HOUR)
def get_firebase_certificates():
    """ Fetches the current Firebase certificates. """
    return requests.get(FIREBASE_CERTIFICATES_URL).json()

@ttl_cache(maxsize=4, ttl=ONE_HOUR)
def extract_public_key_from_certificate(x509_certificate):
    """Extracts the PEM public key from an x509 certificate."""
    der_certificate_string = ssl.PEM_cert_to_DER_cert(x509_certificate)

    # Extract subjectPublicKeyInfo field from X.509 certificate (see RFC3280)
    der_certificate = asn1.DerSequence()
    der_certificate.decode(der_certificate_string)
    tbs_certification = asn1.DerSequence()  # To Be Signed certificate
    tbs_certification.decode(der_certificate[0])

    subject_public_key_info = tbs_certification[6]

    return subject_public_key_info

def firebase_jwt_claims():
    """Verifies the JWT auth token in the request.

    If no token is found or if the token is invalid, returns None.
    Otherwise, it returns a dictionary containing the JWT claims.
    """
    if 'Authorization' not in request.headers:
        return None

    request_jwt = get_jwt_from_headers()

    # Determine which certificate was used to sign the JWT.
    header = jwt.get_unverified_header(request_jwt)
    kid = header['kid']

    certificates = get_firebase_certificates()

    try:
        certificate = certificates[kid]
    except KeyError:
        logging.warning('JWT signed with unknown kid {}'.format(header['kid']))
        return None

    # Get the public key from the certificate. This is used to verify the JWT signature.
    public_key = extract_public_key_from_certificate(certificate)

    try:
        claims = jwt.decode(
            request_jwt,
            public_key,
            algorithms=['RS256'],
            audience=config.PROJECT_ID,
            issuer='https://securetoken.google.com/{}'.format(config.PROJECT_ID))
    except jwt.exceptions.InvalidTokenError as e:
        logging.warning('JWT verification failed: {}'.format(e))
        return None

    return claims

def get_jwt_from_headers():
  # Auth header is in format 'Bearer {jwt}'.
  return request.headers['Authorization'].split(' ').pop()
