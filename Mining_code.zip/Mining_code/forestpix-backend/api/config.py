# The secret key is used by Flask to encrypt session cookies.
SECRET_KEY = '7sqNHYpLfxYArpXfgG47KMAeqVQbU3tjrku9N6NFNAy42vNMB3'

PROJECT_ID = 'herp-atlas-f960c'
