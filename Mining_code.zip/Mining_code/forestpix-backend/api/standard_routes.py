
APP_ENGINE_HEALTHCHECK_PATH = '/_ah/health'
APP_ENGINE_HEALTHCHECK_REGEX = '^{}$'.format(APP_ENGINE_HEALTHCHECK_PATH)

def setup(app):
  @app.route(APP_ENGINE_HEALTHCHECK_PATH, methods=['GET'])
  def healthcheck():
    return 'ok', 200

  @app.errorhandler(500)
  def server_error(e):
    return "500: An internal error occurred.", 500

